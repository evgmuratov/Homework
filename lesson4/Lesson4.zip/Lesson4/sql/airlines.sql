SELECT airlines.airline
 FROM airlines 
WHERE additionalSpaceService='no' 
AND webRegistration='yes'
 AND isMealincluded='no' 
AND flightNumber=1003