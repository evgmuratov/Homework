SELECT airports.airport
 FROM airports 
WHERE dutyFree='no' 
AND priorityBoarding='yes'