CREATE TABLE airports
(
airport varchar(255) NOT NULL,
dutyFree varchar(3),
priorityBoarding varchar(3),
PRIMARY KEY (airport)
); 
