CREATE TABLE airlines
(
flightNumber integer NOT NULL, airline varchar(255),
 additionalSpaceService varchar(3), webRegistration varchar(3),
 isMealincluded varchar(3), PRIMARY KEY (flightNumber)
); 

