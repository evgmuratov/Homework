package main;
import java.sql.*;
public class TestQuery4 {
	public static String Execute(){
			String airport=null;   
			ResultSet rs = QueryExecutor.Execute("sql/airports.sql");
			      //STEP 1: Extract data from result set
			      try {
					if (rs.next()) {			    	    
					  airport  = rs.getString("airport");
					  }
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			    //STEP 2: Clean-up environment
			     try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			   String result = null;
			   if (airport.equals("Beijing")){
				result="passed";
			}else{
				result="failed";
			}
		return result;
		}
}
