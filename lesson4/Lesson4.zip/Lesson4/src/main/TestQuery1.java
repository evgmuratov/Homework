package main;
import java.sql.*;
public class TestQuery1 {
		public static String Execute(){
			int flightNumber=0;   
			ResultSet rs = QueryExecutor.Execute("sql/userStory1.sql");
			    //STEP 1: Extract data from result set
			      try {
					if (rs.next()) {			    	    
					  flightNumber  = rs.getInt("flightNumber");
					  }
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			      try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			   String result = null;
			   if (flightNumber==1001){
				result="passed";
			}else{
				result="failed";
			}
		return result;
		}
}
