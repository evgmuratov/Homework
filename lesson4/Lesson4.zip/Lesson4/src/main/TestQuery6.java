package main;
import java.sql.*;
public class TestQuery6 {
	public static String Execute(){
			String airline=null;   
			ResultSet rs = QueryExecutor.Execute("sql/airlines.sql");
			      //STEP 1: Extract data from result set
			      try {
					if (rs.next()) {			    	    
						  airline  = rs.getString("airline");
					  }
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			    //STEP 2: Clean-up environment
			      try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}			   
			   String result = null;
			   if (airline.equals("Lufthansa")){
				result="passed";
			}else{
				result="failed";
			}
		return result;
		}
}
