package main;

import java.io.IOException;

import jxl.read.biff.BiffException;
import jxl.write.WriteException;

public class RunningTests {
	static String[] testCases=new String[9];
	static String[] results=new String[9];
	public static void main(String[] args) {
		//CreateTables.Execute("sql/airlinesCreateTable.sql");
		//CreateTables.Execute("sql/airportsCreateTable.sql");
		//CreateTables.Execute("sql/flightsCreateTable.sql");
		//FillTables.Execute("sql/airlinesFillTable.sql");
		//FillTables.Execute("sql/airportsFillTable.sql");
		//FillTables.Execute("sql/flightsFillTable.sql");
		testCases[0] = "TestQuery4";
		results[0] = TestQuery4.Execute();
		testCases[1] = "TestQuery5";
		results[1] = TestQuery5.Execute();
		testCases[2] = "TestQuery6";
		results[2] = TestQuery6.Execute();
		testCases[3] = "TestQuery7";
		results[3] = TestQuery7.Execute();
		testCases[4] = "TestQuery8";
		results[4] = TestQuery8.Execute();
		testCases[5] = "TestQuery9";
		results[5] = TestQuery9.Execute();
		testCases[6] = "TestQuery1";
		results[6] = TestQuery1.Execute();
		testCases[7] = "TestQuery2";
		results[7] = TestQuery2.Execute();
		testCases[8] = "TestQuery3";
		results[8] = TestQuery3.Execute();
		try {
			Output.Execute(testCases, results);
		} catch (BiffException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (WriteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	System.out.println("Tests are finished");
	}

}
