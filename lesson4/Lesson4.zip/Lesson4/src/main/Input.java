package main;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import org.apache.commons.lang3.StringUtils;
public class Input {
	public static String readFromFile(String fileName) throws IOException {
		// Specify path to your file
		File file = new File(fileName);
		// Create special input stream for reading data
		FileInputStream fis = new FileInputStream(file);
		//Construct BufferedReader from InputStreamReader
		BufferedReader br = new BufferedReader(new InputStreamReader(fis));
		// Print all existing lines from file to the console
		String line = null;
		ArrayList<String> storage = new ArrayList<String>();
		while ((line = br.readLine()) != null) {
		storage.add(line);
		}
		br.close();
		line = StringUtils.join(storage,"");
		return line;
	}

}
