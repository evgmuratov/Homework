package main;
import java.sql.*;
public class TestQuery5 {
	public static String Execute(){
			int flightNumber=0;   
			ResultSet rs = QueryExecutor.Execute("sql/flights.sql");
			      //STEP 1: Extract data from result set
			      try {
					if (rs.next()) {			    	    
					  flightNumber  = rs.getInt("flightNumber");
					  }
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			    //STEP 2: Clean-up environment
			      try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			  String result = null;
			   if (flightNumber==1012){
				result="passed";
			}else{
				result="failed";
			}
		return result;
		}
}
