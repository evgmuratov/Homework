package main;
import java.sql.*;
public class TestQuery7 {
	public static String Execute(){
			int flightNumber=0;   
			ResultSet rs = QueryExecutor.Execute("sql/airport_flight.sql");
			      //STEP 1: Extract data from result set
			      try {
					if (rs.next()) {			    	    
						  flightNumber  = rs.getInt("flightNumber");
					  }
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			    //STEP 2: Clean-up environment
			     try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			  String result = null;
			   if (flightNumber==1024){
				result="passed";
			}else{
				result="failed";
			}
		return result;
		}
}
