package main;
import java.sql.*;
public class CreateTables {
	// JDBC driver name and database URL
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	static final String DB_URL = "jdbc:mysql://localhost:3306/test?autoReconnect=true&useSSL=false";
	//  Database credentials
	static final String USER = "root";
	static final String PASS = "life648100";
	public static void Execute(String fileName) {
		Connection connect = null;
		Statement query = null;
		   try{
		      //STEP 2: Register JDBC driver
		      Class.forName(JDBC_DRIVER).newInstance();
		      //STEP 3: Open a connection
		      System.out.println("Connecting to database...");
		      connect = DriverManager.getConnection(DB_URL,USER,PASS);
		      System.out.println("Connected database successfully...");
		      //STEP 4: Execute a query
		      System.out.println("Creating statement...");
		      query = connect.createStatement();
		      String sql = Input.readFromFile(fileName);
		      query.executeUpdate(sql);
		      System.out.println("Created table in given database...");
		      //STEP 6: Clean-up environment
		      query.close();
		      connect.close();
		   }catch(SQLException se){
		      //Handle errors for JDBC
		      se.printStackTrace();
		   }catch(Exception e){
		      //Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
		      //finally block used to close resources
		      try{
		         if(query!=null)
		        	 query.close();
		      }catch(SQLException se2){
		      }// nothing we can do
		      try{
		         if(connect!=null)
		            connect.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }//end try
		   System.out.println("Goodbye!");
		}
}
