package main;
import java.io.File;
import java.io.IOException;
import jxl.CellView;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.*;
public class Output {
	 public static void Execute(String[] testCases, String[] testResults) throws BiffException, IOException, WriteException {
		WritableWorkbook myWorkbook;
		myWorkbook= Workbook.createWorkbook(new File("TestReport.xls"));
		WritableSheet mySheet = myWorkbook.createSheet("FirstRun", 0);
		 // Create cell font and format
	    WritableFont cellFont = new WritableFont(WritableFont.TIMES, 12);
	    cellFont.setBoldStyle(WritableFont.BOLD);
	    WritableCellFormat cellFormat = new WritableCellFormat(cellFont);
	    // Create the label, specifying content and format
	   	Label label = new Label(0, 0, "Number", cellFormat);
		mySheet.addCell(label);
		label = new Label(1, 0, "Test Case Name", cellFormat);
		mySheet.addCell(label);
		label = new Label(2, 0, "Result", cellFormat);
		mySheet.addCell(label);
		WritableFont cellFont2 = new WritableFont(WritableFont.TIMES, 12);
		cellFont2.setBoldStyle(WritableFont.NO_BOLD);
	    cellFormat = new WritableCellFormat(cellFont2);
	    WritableCellFormat cellFormat2 = new WritableCellFormat(cellFont2);
	    cellFormat2.setBackground (jxl.format.Colour.GREEN);
	    WritableCellFormat cellFormat3 = new WritableCellFormat(cellFont2);
	    cellFormat3.setBackground (jxl.format.Colour.RED);
	   	    
	    //Add content
		for (int i=0; i<testCases.length; i++){
			mySheet.addCell(new Label(0, i+1, String.valueOf(i+1), cellFormat));
			mySheet.addCell(new Label(1, i+1, testCases[i], cellFormat));
			if (testResults[i].equals("passed")){
			mySheet.addCell(new Label(2, i+1, testResults[i], cellFormat2));
	 }else{
		 mySheet.addCell(new Label(2, i+1, testResults[i], cellFormat3));
	 }
		}
				
		//Columns auto size
		int c = mySheet.getColumns();
		for(int x=0;x<c;x++)
		{
		    CellView cell = new CellView(); 
		    cell=mySheet.getColumnView(x);
		    cell.setAutosize(true);
		    mySheet.setColumnView(x, cell);
		}
		myWorkbook.write();
		myWorkbook.close();
	}
	
}

