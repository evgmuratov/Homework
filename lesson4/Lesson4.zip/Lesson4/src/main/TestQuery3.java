package main;
import java.sql.*;
public class TestQuery3 {
	public static String Execute(){
		String[] airCompany = new String[2]; 	      
		ResultSet rs = QueryExecutor.Execute("sql/userStory3.sql");
		//STEP 1: Extract data from result set
		for (int i=0; i<2; i++){
			try {
				if (rs.next()) {
					airCompany[i]  = rs.getString("airCompany");
					}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		try {
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String result = null;
		if (airCompany[0].equals("AirAsia") || airCompany[1].equals("Lufthansa")){
			result="passed";
			}else{
				result="failed";
			}
		return result;
		}
}
